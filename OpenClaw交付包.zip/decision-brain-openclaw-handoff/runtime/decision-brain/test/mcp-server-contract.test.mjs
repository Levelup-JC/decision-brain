import test from "node:test";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import { mkdtemp } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";

import { listTools, callTool } from "../src/service-contract.mjs";

test("service contract exposes lobster-facing tools", async () => {
  const tools = listTools();
  const toolNames = tools.map((tool) => tool.name);

  assert.deepEqual(
    toolNames,
    [
      "capabilities",
      "manage_position",
      "confirm_plan",
      "get_asset_context",
      "review_add_intent",
      "review_sell_intent",
      "run_daily_monitor",
      "log_source",
      "archive_asset"
    ]
  );

  const health = await callTool("health");
  assert.equal(health.ok, true);
});

test("mcp server responds with content-length framed initialize result", async () => {
  const dataDir = await mkdtemp(join(tmpdir(), "decision-brain-mcp-"));
  const child = spawn("node", ["src/mcp-server.mjs"], {
    cwd: process.cwd(),
    stdio: ["pipe", "pipe", "pipe"],
    env: {
      ...process.env,
      DECISION_BRAIN_DATA_DIR: dataDir
    }
  });

  const request = JSON.stringify({
    jsonrpc: "2.0",
    id: 1,
    method: "initialize",
    params: {}
  });
  child.stdin.write(`Content-Length: ${Buffer.byteLength(request, "utf8")}\r\n\r\n${request}`);

  const output = await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("Timed out waiting for MCP response")), 5000);
    const chunks = [];
    child.stdout.on("data", (chunk) => {
      chunks.push(chunk);
      const text = Buffer.concat(chunks).toString("utf8");
      if (/"serverInfo"/.test(text)) {
        clearTimeout(timer);
        resolve(text);
      }
    });
  });

  child.kill();

  assert.match(output, /Content-Length:/);
  assert.match(output, /"serverInfo"/);
});

test("service contract can execute lobster core flow with isolated state", async () => {
  const dataDir = await mkdtemp(join(tmpdir(), "decision-brain-contract-"));
  const previousDataDir = process.env.DECISION_BRAIN_DATA_DIR;
  const previousStateFile = process.env.DECISION_BRAIN_STATE_FILE;

  process.env.DECISION_BRAIN_DATA_DIR = dataDir;
  delete process.env.DECISION_BRAIN_STATE_FILE;

  try {
    const managed = await callTool("manage_position", {
      assetQuery: "SOL",
      units: 100,
      averageCost: 120,
      currentPrice: 175,
      portfolioValue: 50000,
      naturalLanguagePlan: "2x 回本金，3x 卖 30%，保留历史最高持仓 20% 底仓"
    });

    assert.equal(managed.ok, true);

    const confirmed = await callTool("confirm_plan", {
      assetQuery: "SOL"
    });
    assert.equal(confirmed.ok, true);
    assert.equal(confirmed.plan.status, "active");

    const context = await callTool("get_asset_context", {
      assetQuery: "SOL"
    });
    assert.equal(context.ok, true);
    assert.equal(context.asset.symbol, "SOL");
    assert.equal(context.plan.status, "active");
  } finally {
    if (previousDataDir === undefined) {
      delete process.env.DECISION_BRAIN_DATA_DIR;
    } else {
      process.env.DECISION_BRAIN_DATA_DIR = previousDataDir;
    }
    if (previousStateFile === undefined) {
      delete process.env.DECISION_BRAIN_STATE_FILE;
    } else {
      process.env.DECISION_BRAIN_STATE_FILE = previousStateFile;
    }
  }
});

test("mcp server can list tools and handle a manage_position call", async () => {
  const dataDir = await mkdtemp(join(tmpdir(), "decision-brain-mcp-flow-"));
  const child = spawn("node", ["src/mcp-server.mjs"], {
    cwd: process.cwd(),
    stdio: ["pipe", "pipe", "pipe"],
    env: {
      ...process.env,
      DECISION_BRAIN_DATA_DIR: dataDir
    }
  });

  function send(message) {
    const body = JSON.stringify(message);
    child.stdin.write(`Content-Length: ${Buffer.byteLength(body, "utf8")}\r\n\r\n${body}`);
  }

  let stdoutBuffer = "";
  child.stdout.on("data", (chunk) => {
    stdoutBuffer += chunk.toString("utf8");
  });

  async function waitFor(pattern) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error(`Timed out waiting for ${pattern}`)), 5000);
      const check = () => {
        if (pattern.test(stdoutBuffer)) {
          clearTimeout(timer);
          resolve(stdoutBuffer);
          return true;
        }
        return false;
      };

      if (check()) {
        return;
      }

      const interval = setInterval(() => {
        if (check()) {
          clearInterval(interval);
        }
      }, 20);

      child.on("exit", () => {
        clearTimeout(timer);
        clearInterval(interval);
        if (!pattern.test(stdoutBuffer)) {
          reject(new Error(`Process exited before matching ${pattern}`));
        }
      });
    });
  }

  send({
    jsonrpc: "2.0",
    id: 1,
    method: "initialize",
    params: {}
  });
  await waitFor(/"serverInfo"/);

  send({
    jsonrpc: "2.0",
    id: 2,
    method: "tools/list",
    params: {}
  });
  const listed = await waitFor(/"manage_position"/);
  assert.match(listed, /"capabilities"/);

  send({
    jsonrpc: "2.0",
    id: 3,
    method: "tools/call",
    params: {
      name: "manage_position",
      arguments: {
        assetQuery: "SOL",
        units: 100,
        averageCost: 120,
        currentPrice: 175,
        portfolioValue: 50000
      }
    }
  });
  const called = await waitFor(/当前计划状态为 draft/);
  child.kill();

  assert.match(called, /\\"assetSymbol\\": \\"SOL\\"/);
});
