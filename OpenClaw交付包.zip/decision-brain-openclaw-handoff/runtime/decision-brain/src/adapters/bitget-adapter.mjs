function buildMockSkillNotes(asset) {
  const notesBySymbol = {
    SOL: {
      macro: "主流风险资产环境改善时，SOL 往往具备更高 beta 弹性。",
      marketIntel: "生态活跃与资金轮动是核心观察点。",
      news: "机构叙事和 ETF 方向容易影响预期上限。",
      sentiment: "上涨过快时容易触发情绪化追高或止盈。",
      technical: "更适合用阶段和估值区间管理，而不是只盯短线波动。 "
    },
    ENA: {
      macro: "收益和稳定币叙事会放大宏观风险偏好的影响。",
      marketIntel: "TVL 与资金费率环境是关键跟踪项。",
      news: "产品扩张与合规风险都会直接影响估值中枢。",
      sentiment: "叙事热度变化会显著影响资金追逐程度。",
      technical: "高 beta 下回撤较大，更适合设清晰仓位上限。"
    },
    ZORA: {
      macro: "宏观影响次于注意力与流动性，但风险偏好仍决定上限。",
      marketIntel: "链上活跃、分发与流动性深度最关键。",
      news: "上所、分发合作与生态动向需要持续盯。",
      sentiment: "注意力型资产更容易受叙事退潮影响。",
      technical: "技术面只作为辅助，核心仍是流动性和估值区间。"
    }
  };

  return notesBySymbol[asset.symbol] || {
    macro: "需要补充真实宏观分析。",
    marketIntel: "需要补充真实链上与资金面信息。",
    news: "需要补充真实新闻摘要。",
    sentiment: "需要补充真实情绪数据。",
    technical: "需要补充真实技术指标。"
  };
}

export function createBitgetAdapter() {
  return {
    name: "bitget-mock-adapter",
    getSkillNotes(asset) {
      return buildMockSkillNotes(asset);
    },
    scanDailySignals(asset) {
      const notes = buildMockSkillNotes(asset);
      return {
        summary: `${asset.symbol} 今日按照 Bitget mock skill 节奏完成一次信号扫描。`,
        highlights: [notes.news, notes.marketIntel, notes.sentiment]
      };
    }
  };
}
