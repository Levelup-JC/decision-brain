import { createBitgetAdapter } from "./bitget-adapter.mjs";
import { createSurfAdapter } from "./surf-adapter.mjs";

export function getAdapters() {
  return {
    bitget: createBitgetAdapter(),
    surf: createSurfAdapter()
  };
}
