import { store } from "../data-store.mjs";
import { resolveAssetFromQuery } from "./asset-service.mjs";
import { buildResearchReport } from "./research-service.mjs";
import { buildValuationModel, detectValuationZone } from "./valuation-service.mjs";
import { buildDraftPlan } from "./plan-service.mjs";
import { buildAddRecommendation, buildSellRecommendation } from "./recommendation-service.mjs";
import { entityId } from "../utils/ids.mjs";
import { nowIso } from "../utils/time.mjs";
import { runMonitorForState } from "./monitor-service.mjs";

function requireField(value, fieldName) {
  if (value === undefined || value === null || value === "") {
    throw new Error(`Missing required field: ${fieldName}`);
  }
}

function stateSummary(state) {
  return {
    ok: true,
    counts: {
      assets: Object.keys(state.assets).length,
      positions: Object.keys(state.positions).length,
      sources: Object.keys(state.sources || {}).length,
      plans: Object.keys(state.plans).length,
      events: Object.keys(state.events).length,
      traces: Object.keys(state.traces).length
    },
    assets: Object.values(state.assets),
    positions: Object.values(state.positions),
    sources: Object.values(state.sources || {}),
    plans: Object.values(state.plans),
    valuationModels: Object.values(state.valuationModels),
    recentEvents: Object.values(state.events).slice(-10),
    recentTraces: Object.values(state.traces).slice(-10)
  };
}

export async function getStateSummary() {
  const state = await store.load();
  return stateSummary(state);
}

export async function getAssetContext(assetQuery) {
  requireField(assetQuery, "assetQuery");
  const state = await store.load();
  const asset = resolveAssetFromQuery(assetQuery, state.assets);
  const position = state.positions[asset.id] || null;
  const researchReport = state.researchReports[asset.id] || null;
  const valuationModel = state.valuationModels[asset.id] || null;
  const plan = state.plans[asset.id] || null;
  const recentEvents = Object.values(state.events)
    .filter((event) => event.assetId === asset.id)
    .slice(-5);
  const recentSources = Object.values(state.sources || {})
    .filter((source) => source.assetId === asset.id)
    .slice(-10);
  const recentTraces = Object.values(state.traces)
    .filter((trace) => trace.assetId === asset.id)
    .slice(-5);
  const monitorState = state.monitorState[asset.id] || null;

  return {
    ok: true,
    asset,
    position,
    researchReport,
    valuationModel,
    plan,
    recentSources,
    recentEvents,
    recentTraces,
    monitorState,
    memorySummary: {
      status: plan?.status || "unmanaged",
      thesis: researchReport?.thesis || [],
      catalysts: researchReport?.catalysts || [],
      risks: researchReport?.risks || [],
      listedExchanges: researchReport?.listedExchanges || [],
      potentialExchanges: researchReport?.potentialExchanges || [],
      sourceCount: recentSources.length,
      valuationZone: valuationModel ? detectValuationZone(valuationModel) : "unknown",
      nextReviewAt: plan?.nextReviewAt || null,
      lastNewsUpdateAt: monitorState?.lastNewsUpdateAt || null,
      lastPositionUpdateAt: monitorState?.lastPositionUpdateAt || null,
      portfolioContextComplete: Boolean(position?.portfolioContextComplete),
      latestEventTitle: recentEvents[recentEvents.length - 1]?.title || null
    }
  };
}

export function buildCapabilities() {
  return {
    ok: true,
    service: "decision-brain",
    positioning: {
      role: "investment_decision_brain",
      notFor: ["auto_trading", "private_key_management", "high_frequency_monitoring"],
      monitoringCadence: {
        news: "once_per_24h",
        position: "once_per_24h"
      },
      supportedAssets: ["stocks", "major_crypto", "cex_tokens", "onchain_tokens"],
      adviceStyle: "final_investment_recommendation"
    },
    agentPlaybook: {
      alwaysReadContextBeforeAdvice: true,
      preferredAssetIdentifier: "assetQuery",
      workflow: [
        "manage-position when the user first buys or starts watching an asset",
        "confirm-plan after the user accepts the generated draft plan",
        "get-asset-context before answering any follow-up question about that asset",
        "review-add-intent when the user asks whether to add",
        "review-sell-intent when the user asks whether to sell",
        "run-daily-monitor once per day",
        "log-source whenever the agent reads an external source worth keeping",
        "archive-asset when the asset is no longer actively managed"
      ],
      memoryRules: [
        "do not keep a separate shadow memory outside Decision Brain",
        "write long-lived research evidence back through log-source",
        "do not poll run-daily-monitor more than once every 24 hours unless force is explicitly needed"
      ],
      recommendationRules: [
        "use price curve only as one input, never as the only reason",
        "check valuation, events, thesis state, and floor rule before suggesting a sell",
        "check portfolio allocation and sector exposure before suggesting an add"
      ]
    },
    tools: [
      {
        name: "manage-position",
        method: "POST",
        path: "/api/manage-position",
        purpose: "识别资产、写入仓位、自动调研、生成估值和 draft 计划"
      },
      {
        name: "confirm-plan",
        method: "POST",
        path: "/api/confirm-plan",
        purpose: "确认 draft 计划并启动 active 监控"
      },
      {
        name: "review-add-intent",
        method: "POST",
        path: "/api/review-add-intent",
        purpose: "基于仓位和估值给加仓建议"
      },
      {
        name: "review-sell-intent",
        method: "POST",
        path: "/api/review-sell-intent",
        purpose: "基于仓位、底仓和估值给卖出建议"
      },
      {
        name: "run-daily-monitor",
        method: "POST",
        path: "/api/run-daily-monitor",
        purpose: "执行每日一次的新闻和仓位监测"
      },
      {
        name: "log-source",
        method: "POST",
        path: "/api/log-source",
        purpose: "给某个资产追加结构化来源记录，供龙虾长期记忆和后续复盘使用"
      },
      {
        name: "get-asset-context",
        method: "GET",
        path: "/api/asset-context?asset=SYMBOL",
        purpose: "读取某个资产的完整记忆上下文，方便龙虾持续调用"
      },
      {
        name: "archive-asset",
        method: "POST",
        path: "/api/archive-asset",
        purpose: "归档某个资产的计划和监测状态，避免记忆混乱"
      }
    ]
  };
}

export async function managePosition(body) {
  requireField(body.assetQuery, "assetQuery");

  return store.update(async (state) => {
    const asset = resolveAssetFromQuery(body.assetQuery, state.assets);
    state.assets[asset.id] = asset;

    const researchReport = buildResearchReport(asset, state.researchReports[asset.id]);
    state.researchReports[asset.id] = researchReport;
    for (const source of researchReport.sources || []) {
      state.sources[source.id] = {
        ...source,
        assetId: asset.id,
        assetSymbol: asset.symbol,
        roleInDecision: "research_seed",
        createdAt: source.createdAt || nowIso()
      };
    }

    const existingPosition = state.positions[asset.id];
    const units = Number(body.units ?? existingPosition?.units ?? 0);
    const averageCost = Number(body.averageCost ?? existingPosition?.averageCost ?? 0);
    const currentPrice = Number(body.currentPrice ?? averageCost);
    const currentValue = Number((units * currentPrice).toFixed(2));
    const portfolioValueExplicitlyProvided = body.portfolioValue !== undefined && body.portfolioValue !== null;
    const portfolioValue = Number(
      portfolioValueExplicitlyProvided
        ? body.portfolioValue
        : existingPosition?.portfolioValue || currentValue || 0
    );
    const portfolioPct = portfolioValue > 0 ? currentValue / portfolioValue : Number(existingPosition?.portfolioPct || 0);
    const peakUnits = Math.max(Number(existingPosition?.peakUnits || 0), units);

    const position = {
      assetId: asset.id,
      assetSymbol: asset.symbol,
      units,
      averageCost,
      costBasisTotal: Number((units * averageCost).toFixed(2)),
      currentPrice,
      currentValue,
      portfolioValue,
      portfolioContextComplete: portfolioValueExplicitlyProvided || Boolean(existingPosition?.portfolioContextComplete),
      peakUnits,
      portfolioPct,
      sectorExposurePct: Number(body.sectorExposurePct || existingPosition?.sectorExposurePct || 0),
      cashPct: Number(body.cashPct || existingPosition?.cashPct || 0),
      marketCap: Number(body.marketCap || researchReport.currentMetrics?.marketCap || existingPosition?.marketCap || 0),
      fdv: Number(body.fdv || researchReport.currentMetrics?.fdv || existingPosition?.fdv || 0),
      liquidityUsd: Number(body.liquidityUsd || existingPosition?.liquidityUsd || 0),
      dailyVolumeUsd: Number(body.dailyVolumeUsd || existingPosition?.dailyVolumeUsd || 0),
      updatedAt: nowIso()
    };
    state.positions[asset.id] = position;

    const valuationModel = buildValuationModel(asset, position, researchReport, state.valuationModels[asset.id]);
    state.valuationModels[asset.id] = valuationModel;

    const plan = buildDraftPlan(
      asset,
      position,
      valuationModel,
      body.naturalLanguagePlan,
      state.plans[asset.id]
    );
    state.plans[asset.id] = plan;

    state.traces[entityId("trace")] = {
      id: entityId("trace"),
      assetId: asset.id,
      userIntent: "manage_position",
      finalRecommendation: `${asset.symbol} 已生成 draft 投资计划，等待确认`,
      reasons: [
        "已完成资产识别和仓位写入",
        "已生成项目调研摘要",
        "已生成对标估值模型",
        "计划需要用户确认后才正式进入 active"
      ],
      createdAt: nowIso()
    };

    return {
      ok: true,
      asset,
      position,
      researchReport,
      valuationModel,
      plan,
      message: `${asset.symbol} 已经进入管理流程，当前计划状态为 ${plan.status}`
    };
  });
}

export async function confirmPlan(body) {
  requireField(body.assetQuery || body.planId, "assetQuery or planId");

  return store.update(async (state) => {
    let plan = null;
    if (body.planId) {
      plan = Object.values(state.plans).find((item) => item.id === body.planId);
    } else {
      const asset = resolveAssetFromQuery(body.assetQuery, state.assets);
      plan = state.plans[asset.id];
    }

    if (!plan) {
      throw new Error("Plan not found");
    }

    plan.status = "active";
    plan.confirmedAt = nowIso();
    plan.updatedAt = nowIso();
    state.plans[plan.assetId] = plan;
    state.monitorState[plan.assetId] = state.monitorState[plan.assetId] || {};

    state.traces[entityId("trace")] = {
      id: entityId("trace"),
      assetId: plan.assetId,
      userIntent: "confirm_plan",
      finalRecommendation: "计划已确认并进入 active 监控",
      reasons: ["后续新闻和仓位监测将按 24 小时节奏运行"],
      createdAt: nowIso()
    };

    return {
      ok: true,
      plan,
      monitoringPolicy: plan.monitoringPolicy
    };
  });
}

export async function reviewAddIntent(body) {
  requireField(body.assetQuery, "assetQuery");

  return store.update(async (state) => {
    const asset = resolveAssetFromQuery(body.assetQuery, state.assets);
    const position = state.positions[asset.id];
    const valuationModel = state.valuationModels[asset.id];
    const plan = state.plans[asset.id];
    const researchReport = state.researchReports[asset.id];
    const latestEvent = Object.values(state.events)
      .filter((event) => event.assetId === asset.id)
      .sort((a, b) => String(b.createdAt || "").localeCompare(String(a.createdAt || "")))[0];

    if (!position || !valuationModel || !plan) {
      throw new Error(`No managed position found for ${asset.symbol}`);
    }

    const result = buildAddRecommendation({
      asset,
      position,
      valuationModel,
      plan,
      totalPortfolioValue: Number(body.portfolioValue || 0),
      researchReport,
      latestEvent
    });

    state.traces[entityId("trace")] = {
      id: entityId("trace"),
      assetId: asset.id,
      userIntent: "review_add_intent",
      finalRecommendation: result.finalRecommendation,
      reasons: result.reasons,
      createdAt: nowIso()
    };

    return result;
  });
}

export async function reviewSellIntent(body) {
  requireField(body.assetQuery, "assetQuery");
  requireField(body.requestedSellPct, "requestedSellPct");

  return store.update(async (state) => {
    const asset = resolveAssetFromQuery(body.assetQuery, state.assets);
    const position = state.positions[asset.id];
    const valuationModel = state.valuationModels[asset.id];
    const plan = state.plans[asset.id];
    const researchReport = state.researchReports[asset.id];
    const latestEvent = Object.values(state.events)
      .filter((event) => event.assetId === asset.id)
      .sort((a, b) => String(b.createdAt || "").localeCompare(String(a.createdAt || "")))[0];

    if (!position || !valuationModel || !plan) {
      throw new Error(`No managed position found for ${asset.symbol}`);
    }

    const result = buildSellRecommendation({
      asset,
      position,
      valuationModel,
      plan,
      requestedSellPct: Number(body.requestedSellPct),
      researchReport,
      latestEvent,
      thesisInvalidated: Boolean(body.thesisInvalidated)
    });

    state.traces[entityId("trace")] = {
      id: entityId("trace"),
      assetId: asset.id,
      userIntent: `review_sell_intent:${body.requestedSellPct}%`,
      finalRecommendation: result.finalRecommendation,
      reasons: result.reasons,
      createdAt: nowIso()
    };

    return result;
  });
}

export async function runDailyMonitor(body) {
  return store.update(async (state) => {
    return runMonitorForState(state, Boolean(body.force));
  });
}

export async function logSource(body) {
  requireField(body.assetQuery, "assetQuery");
  requireField(body.title, "title");
  requireField(body.keyClaim, "keyClaim");

  return store.update(async (state) => {
    const asset = resolveAssetFromQuery(body.assetQuery, state.assets);
    if (!state.assets[asset.id]) {
      throw new Error(`No managed asset found for ${asset.symbol}`);
    }

    const source = {
      id: entityId("source"),
      assetId: asset.id,
      assetSymbol: asset.symbol,
      sourceType: body.sourceType || "manual_note",
      author: body.author || "user_or_lobster",
      title: body.title,
      url: body.url || null,
      keyClaim: body.keyClaim,
      roleInDecision: body.roleInDecision || "supporting_evidence",
      confidenceAtTime: Number(body.confidenceAtTime || 0),
      createdAt: nowIso()
    };

    state.sources[source.id] = source;

    state.traces[entityId("trace")] = {
      id: entityId("trace"),
      assetId: asset.id,
      userIntent: "log_source",
      finalRecommendation: `${asset.symbol} 已新增来源记录`,
      reasons: [`来源标题：${source.title}`],
      createdAt: nowIso()
    };

    return {
      ok: true,
      source
    };
  });
}

export async function archiveAsset(body) {
  requireField(body.assetQuery, "assetQuery");

  return store.update(async (state) => {
    const asset = resolveAssetFromQuery(body.assetQuery, state.assets);
    const plan = state.plans[asset.id];

    if (!plan) {
      throw new Error(`No managed asset found for ${asset.symbol}`);
    }

    plan.status = "archived";
    plan.updatedAt = nowIso();
    state.plans[asset.id] = plan;
    delete state.monitorState[asset.id];

    state.traces[entityId("trace")] = {
      id: entityId("trace"),
      assetId: asset.id,
      userIntent: "archive_asset",
      finalRecommendation: `${asset.symbol} 已归档，不再继续自动监测`,
      reasons: ["计划状态已切换为 archived", "每日监测状态已清理"],
      createdAt: nowIso()
    };

    return {
      ok: true,
      asset,
      plan
    };
  });
}
