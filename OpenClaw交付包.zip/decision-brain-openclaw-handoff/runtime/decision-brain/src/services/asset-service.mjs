import { assetIdFromQuery, slugify } from "../utils/ids.mjs";
import { nowIso } from "../utils/time.mjs";

const knownAssets = {
  btc: {
    symbol: "BTC",
    name: "Bitcoin",
    assetType: "major_crypto",
    chain: "bitcoin",
    riskClass: "medium",
    tags: ["store-of-value", "macro"]
  },
  eth: {
    symbol: "ETH",
    name: "Ethereum",
    assetType: "major_crypto",
    chain: "ethereum",
    riskClass: "medium_high",
    tags: ["smart-contract", "l1"]
  },
  sol: {
    symbol: "SOL",
    name: "Solana",
    assetType: "major_crypto",
    chain: "solana",
    riskClass: "medium_high",
    tags: ["l1", "solana-ecosystem"]
  },
  ena: {
    symbol: "ENA",
    name: "Ethena",
    assetType: "cex_alt",
    chain: "ethereum",
    riskClass: "high",
    tags: ["stablecoin", "yield", "ethena"]
  },
  zora: {
    symbol: "ZORA",
    name: "Zora",
    assetType: "onchain_token",
    chain: "base",
    riskClass: "high",
    tags: ["creator", "social", "base"]
  }
};

function inferAssetType(query) {
  if (/^0x[a-fA-F0-9]{40}$/.test(query)) {
    return {
      symbol: `${query.slice(0, 6)}...${query.slice(-4)}`,
      name: "Onchain Token",
      assetType: "onchain_token",
      chain: "evm",
      riskClass: "high",
      tags: ["onchain", "speculative"]
    };
  }

  if (/^[A-Z]{1,5}$/.test(query)) {
    return {
      symbol: query,
      name: query,
      assetType: "stock_or_unknown",
      chain: null,
      riskClass: "medium",
      tags: ["manual-review"]
    };
  }

  return {
    symbol: query.toUpperCase(),
    name: query,
    assetType: "cex_alt",
    chain: null,
    riskClass: "high",
    tags: ["manual-review"]
  };
}

export function resolveAssetFromQuery(assetQuery, existingAssets) {
  const normalized = slugify(assetQuery);
  const known = knownAssets[normalized] || inferAssetType(String(assetQuery || "").trim());
  const existing = Object.values(existingAssets).find((asset) => {
    return (
      asset.symbol?.toLowerCase() === String(known.symbol).toLowerCase() ||
      asset.aliases?.includes(normalized) ||
      asset.contractAddress === assetQuery
    );
  });

  if (existing) {
    return {
      ...existing,
      aliases: Array.from(new Set([...(existing.aliases || []), normalized]))
    };
  }

  return {
    id: assetIdFromQuery(known.symbol || assetQuery),
    symbol: known.symbol,
    name: known.name,
    assetType: known.assetType,
    chain: known.chain,
    contractAddress: /^0x[a-fA-F0-9]{40}$/.test(assetQuery) ? assetQuery : null,
    riskClass: known.riskClass,
    tags: known.tags,
    aliases: normalized ? [normalized] : [],
    createdAt: nowIso(),
    updatedAt: nowIso()
  };
}
