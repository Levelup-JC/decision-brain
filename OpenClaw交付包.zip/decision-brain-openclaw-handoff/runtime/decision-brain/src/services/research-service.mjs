import { entityId, stableId } from "../utils/ids.mjs";
import { nowIso } from "../utils/time.mjs";
import { getAdapters } from "../adapters/index.mjs";

const mockProfiles = {
  SOL: {
    summary: "Solana is tracked as a high-beta major crypto with ecosystem and ETF-style catalyst sensitivity.",
    currentMetrics: {
      marketCap: 75000000000,
      fdv: 102000000000
    },
    thesis: [
      "生态活跃与开发者心智仍然较强",
      "如果风险偏好回升，主流 L1 可能继续获得资金关注",
      "潜在 ETF 或机构叙事会影响估值上限"
    ],
    catalysts: [
      "生态活跃度提升",
      "机构流入和 ETF 相关叙事",
      "主流资金轮动回到高 beta L1"
    ],
    risks: [
      "BTC 风险偏好转弱",
      "生态活跃放缓",
      "短期上涨过快后的获利回吐"
    ],
    comparables: [
      { symbol: "ETH", type: "category_leader", marketCap: 420000000000, fdv: 420000000000, reason: "同为主流智能合约资产" },
      { symbol: "AVAX", type: "direct_comparable", marketCap: 16000000000, fdv: 19000000000, reason: "同类高 beta L1" },
      { symbol: "SUI", type: "aspirational_comparable", marketCap: 8000000000, fdv: 22000000000, reason: "新叙事高 beta L1 对照" }
    ],
    exchangeStatus: "major_cex_listed",
    funding: "mature_ecosystem",
    liquidityNote: "主流流动性较好，适合用估值和阶段来管理仓位",
    listedExchanges: ["Bitget", "Binance", "Coinbase"],
    potentialExchanges: ["ETF / 机构入口扩张"],
    exchangePathHypothesis: "对 SOL 来说重点不在新增上所，而在新增机构入口和叙事通道。",
    marketStructureNote: "主流资金轮动和风险偏好会显著影响估值抬升空间。",
    factualSignals: ["主流交易所均已覆盖", "生态和机构叙事持续被市场跟踪"],
    inferredSignals: ["若机构入口继续扩张，估值上限可能继续上修"]
  },
  ENA: {
    summary: "Ethena is tracked as a high-risk CEX alt tied to stablecoin, synthetic yield, and narrative durability.",
    currentMetrics: {
      marketCap: 2200000000,
      fdv: 6200000000
    },
    thesis: [
      "稳定币收益叙事若持续，ENA 有估值扩张空间",
      "大所流动性与资金费率环境会显著影响表现",
      "如果 TVL 和采用继续增长，基准估值会被上修"
    ],
    catalysts: ["TVL 提升", "产品采用扩张", "叙事重新升温"],
    risks: ["监管压力", "收益模型不被市场持续买单", "高 beta 回撤"],
    comparables: [
      { symbol: "MKR", type: "category_leader", marketCap: 2500000000, fdv: 2600000000, reason: "稳定币治理类龙头对照" },
      { symbol: "LDO", type: "direct_comparable", marketCap: 1400000000, fdv: 1600000000, reason: "收益和治理叙事可对照" },
      { symbol: "PENDLE", type: "aspirational_comparable", marketCap: 900000000, fdv: 1100000000, reason: "收益产品叙事对照" }
    ],
    exchangeStatus: "major_cex_listed",
    funding: "venture_backed",
    liquidityNote: "流动性较强，但叙事回撤时波动会放大",
    listedExchanges: ["Bitget", "Binance", "Bybit"],
    potentialExchanges: ["Coinbase"],
    exchangePathHypothesis: "已具备主流流动性，后续更多取决于产品数据和合规路径，而不是单纯新增上所。",
    marketStructureNote: "稳定币和收益类叙事对市场情绪切换较敏感。",
    factualSignals: ["已获得主流交易所流动性", "机构与高关注叙事仍在"],
    inferredSignals: ["若合规和产品数据同步改善，估值中枢有机会继续上修"]
  },
  ZORA: {
    summary: "Zora is tracked as a high-risk onchain social/creator asset where liquidity, attention, and exchange path matter more than pure multiple targets.",
    currentMetrics: {
      marketCap: 180000000,
      fdv: 620000000
    },
    thesis: [
      "如果 creator/social 叙事继续扩散，ZORA 有被重新定价的空间",
      "Base 生态和社交分发若继续增强，估值中枢有望抬升",
      "交易所流动性和新增分发渠道会显著影响上限"
    ],
    catalysts: ["Base 生态扩张", "社交/creator 叙事升温", "新增上所或流动性改善"],
    risks: ["流动性不足", "叙事退潮", "持仓集中和拉高出货风险"],
    comparables: [
      { symbol: "DEGEN", type: "direct_comparable", marketCap: 180000000, fdv: 400000000, reason: "Base 生态注意力资产对照" },
      { symbol: "FRIEND", type: "downside_comparable", marketCap: 90000000, fdv: 300000000, reason: "社交叙事冷却后的下行对照" },
      { symbol: "BLUR", type: "category_leader", marketCap: 450000000, fdv: 900000000, reason: "创作者/内容交易 attention 资产对照" }
    ],
    exchangeStatus: "mixed_listing",
    funding: "venture_backed_with_distribution_optionality",
    liquidityNote: "流动性和交易所路径对估值中枢影响很大，需要持续跟踪",
    listedExchanges: ["Bitget"],
    potentialExchanges: ["Binance", "Coinbase"],
    exchangePathHypothesis: "理论上存在融资和分发背景支撑，但是否能继续上更大所仍取决于活跃度、合规和流动性承接能力。",
    marketStructureNote: "注意力、流动性深度和做市质量比传统倍数目标更重要。",
    factualSignals: ["已在 Bitget 等渠道获得基础流动性", "Base 生态与 creator 叙事具备分发想象空间"],
    inferredSignals: ["若活跃度和分发继续扩张，新增上所预期仍可能被重新交易"]
  }
};

function buildFallbackProfile(asset) {
  return {
    summary: `${asset.symbol} is currently using a fallback research profile and should be enriched by Bitget or Surf adapters.`,
    currentMetrics: {
      marketCap: 0,
      fdv: 0
    },
    thesis: ["需要补充真实项目研究", "先按高风险资产处理，避免过大仓位"],
    catalysts: ["等待用户补充项目背景", "等待外部研究适配器接入"],
    risks: ["当前研究资料不足", "估值结论可信度有限"],
    comparables: [],
    exchangeStatus: "unknown",
    funding: "unknown",
    liquidityNote: "流动性未知，需要确认",
    listedExchanges: [],
    potentialExchanges: [],
    exchangePathHypothesis: "待补充",
    marketStructureNote: "待补充",
    factualSignals: [],
    inferredSignals: ["当前多数判断仍属推断，需要更多事实来源支撑"]
  };
}

export function buildResearchReport(asset, existingReport) {
  const adapters = getAdapters();
  const skillNotes = adapters.bitget.getSkillNotes(asset);
  const surfDossier = adapters.surf.buildProjectDossier(asset);
  const profile = mockProfiles[asset.symbol] || buildFallbackProfile(asset);
  const reportId = stableId("research", { assetId: asset.id, symbol: asset.symbol });

  return {
    id: existingReport?.id || reportId,
    assetId: asset.id,
    assetSymbol: asset.symbol,
    summary: profile.summary,
    skillNotes,
    surfDossier,
    thesis: profile.thesis,
    catalysts: profile.catalysts,
    risks: profile.risks,
    currentMetrics: profile.currentMetrics,
    comparables: profile.comparables.map((comparable) => ({
      id: entityId("cmp"),
      ...comparable
    })),
    funding: profile.funding,
    exchangeStatus: profile.exchangeStatus,
    listedExchanges: profile.listedExchanges || [],
    potentialExchanges: profile.potentialExchanges || [],
    exchangePathHypothesis: profile.exchangePathHypothesis,
    liquidityNote: profile.liquidityNote,
    marketStructureNote: profile.marketStructureNote,
    factualSignals: profile.factualSignals || [],
    inferredSignals: profile.inferredSignals || [],
    sources: [
      {
        id: existingReport?.sources?.[0]?.id || entityId("source"),
        sourceType: "bitget_skill_mock",
        author: "Decision Brain Mock Adapter",
        title: `${asset.symbol} research seed`,
        keyClaim: profile.summary
      },
      {
        id: existingReport?.sources?.[1]?.id || entityId("source"),
        sourceType: "surf_mock",
        author: "Decision Brain Surf Mock Adapter",
        title: `${asset.symbol} project dossier`,
        keyClaim: surfDossier.projectSummary
      }
    ],
    createdAt: existingReport?.createdAt || nowIso(),
    refreshedAt: nowIso()
  };
}

export function scanDailyEvents(asset, researchReport) {
  const adapters = getAdapters();
  const dailySignals = adapters.bitget.scanDailySignals(asset);
  const triggerKeywords = ["下架", "attack", "hack", "监管", "解锁", "liquidity", "复盘", "恶化", "depeg"];
  const triggerSignals = [
    ...(dailySignals.highlights || []),
    ...(researchReport.inferredSignals || []),
    ...(researchReport.risks || [])
  ];
  const reviewTrigger = triggerSignals.some((item) =>
    triggerKeywords.some((keyword) => String(item || "").toLowerCase().includes(keyword.toLowerCase()))
  );

  return {
    id: entityId("event"),
    assetId: asset.id,
    type: "daily_monitor",
    title: `${asset.symbol} 每日监测摘要`,
    summary: `${dailySignals.summary} 重点关注：${researchReport.catalysts[0] || "无新增 catalyst"}。`,
    sentiment: "neutral",
    relevanceScore: 0.4,
    pricedInAssessment: "unknown",
    factualSignals: dailySignals.highlights.slice(0, 2),
    inferredSignals: researchReport.inferredSignals?.slice(0, 1) || [],
    reviewTrigger,
    sourceType: "daily_monitor",
    createdAt: nowIso()
  };
}
