import { createServer } from "./server.mjs";

const port = Number(process.env.PORT || 4177);
const host = process.env.HOST || "127.0.0.1";

const server = createServer();

server.listen(port, host, () => {
  console.log(`Decision Brain listening on http://${host}:${port}`);
});
