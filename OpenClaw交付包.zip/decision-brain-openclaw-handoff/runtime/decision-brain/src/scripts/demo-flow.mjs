import { store } from "../data-store.mjs";
import {
  confirmPlan,
  getAssetContext,
  managePosition,
  reviewSellIntent,
  runDailyMonitor
} from "../services/api-service.mjs";

const shouldReset = process.argv.includes("--reset");
const assetQuery = process.argv.slice(2).find((arg) => !arg.startsWith("--")) || "SOL";

if (shouldReset) {
  await store.clear();
}

const managed = await managePosition({
  assetQuery,
  units: 100,
  averageCost: 120,
  currentPrice: 175,
  portfolioValue: 50000,
  naturalLanguagePlan: "2x 回本金，3x 卖 30%，保留历史最高持仓 20% 底仓"
});

const confirmed = await confirmPlan({ assetQuery });
const monitor = await runDailyMonitor({});
const sellReview = await reviewSellIntent({
  assetQuery,
  requestedSellPct: 80
});
const context = await getAssetContext(assetQuery);

const payload = {
  managed: {
    asset: managed.asset.symbol,
    planStatus: managed.plan.status,
    thesis: managed.researchReport.thesis
  },
  confirmed: {
    planStatus: confirmed.plan.status
  },
  monitor,
  sellReview,
  contextSummary: context.memorySummary
};

process.stdout.write(`${JSON.stringify(payload, null, 2)}\n`);
