function formatCompactNumber(value) {
  const number = Number(value || 0);
  if (!Number.isFinite(number) || number <= 0) {
    return "暂无";
  }

  if (number >= 1_0000_0000_0000) {
    return `${(number / 1_0000_0000_0000).toFixed(number >= 10_0000_0000_0000 ? 0 : 1)}万亿`;
  }
  if (number >= 1_0000_0000) {
    return `${(number / 1_0000_0000).toFixed(number >= 1000_0000_0000 ? 0 : 1)}亿`;
  }
  if (number >= 1_0000) {
    return `${(number / 1_0000).toFixed(number >= 100_0000 ? 0 : 1)}万`;
  }
  return number.toLocaleString("zh-CN");
}

function formatUsdRange(range) {
  if (!Array.isArray(range) || range.length !== 2) {
    return "暂无";
  }
  return `${formatCompactNumber(range[0])} - ${formatCompactNumber(range[1])}`;
}

function normalizePlanText(text) {
  const value = String(text || "");
  return value.replace(/\b\d{8,}\b/g, (match) => formatCompactNumber(Number(match)));
}

function zoneLabel(zone) {
  const map = {
    below_conservative: "低于保守区",
    conservative: "保守区",
    base: "基准区",
    aggressive: "高估值区",
    between_base_and_aggressive: "基准区上方"
  };
  return map[zone] || zone || "未知";
}

function detectValuationZone(valuation) {
  if (!valuation?.currentMetrics?.fdv || !valuation?.scenarios?.length) {
    return "unknown";
  }

  const currentFdv = Number(valuation.currentMetrics.fdv || 0);
  const conservative = valuation.scenarios.find((scenario) => scenario.name === "conservative");
  const base = valuation.scenarios.find((scenario) => scenario.name === "base");
  const aggressive = valuation.scenarios.find((scenario) => scenario.name === "aggressive");

  if (!conservative || !base || !aggressive) {
    return "unknown";
  }

  const [cMin, cMax] = conservative.targetFdvRange;
  const [, bMax] = base.targetFdvRange;
  const [aMin] = aggressive.targetFdvRange;

  if (currentFdv <= cMin) {
    return "below_conservative";
  }
  if (currentFdv <= cMax) {
    return "conservative";
  }
  if (currentFdv <= bMax) {
    return "base";
  }
  if (currentFdv >= aMin) {
    return "aggressive";
  }
  return "between_base_and_aggressive";
}

function renderStats(counts) {
  const stats = document.getElementById("stats");
  stats.innerHTML = [
    ["资产", counts.assets],
    ["仓位", counts.positions],
    ["计划", counts.plans],
    ["记录", counts.traces]
  ]
    .map(
      ([label, value]) => `
        <div class="panel stat">
          <div class="stat-value">${value}</div>
          <div class="stat-label">${label}</div>
        </div>
      `
    )
    .join("");
}

function renderAssets(state) {
  const root = document.getElementById("assets");
  const items = state.assets.map((asset) => {
    const position = state.positions.find((entry) => entry.assetId === asset.id);
    const plan = state.plans.find((entry) => entry.assetId === asset.id);
    const valuation = state.valuationModels.find((entry) => entry.assetId === asset.id);
    const baseScenario = valuation?.scenarios?.find((scenario) => scenario.name === "base");
    const sources = state.sources.filter((entry) => entry.assetId === asset.id);
    const recentEvent = state.recentEvents.find((entry) => entry.assetId === asset.id);
    const valuationZone = detectValuationZone(valuation);
    const currentFdv = valuation?.currentMetrics?.fdv;
    const currentPrice = position?.currentPrice;
    const averageCost = position?.averageCost;

    return `
      <div class="card">
        <div style="display:flex;justify-content:space-between;gap:12px;align-items:start;">
          <div>
            <strong>${asset.symbol}</strong>
            <div class="muted">${asset.name} · ${asset.assetType}</div>
          </div>
          <span class="badge">${plan?.status || "unplanned"}</span>
        </div>
        <div class="muted" style="margin-top:8px;">
          当前仓位：${position?.units ?? 0} · 成本：${position?.averageCost ?? 0} · 历史峰值：${position?.peakUnits ?? 0}
        </div>
        <div style="margin-top:10px; display:grid; gap:6px;">
          <div class="metric-row">
            <span class="metric-label">当前 FDV</span>
            <strong>${formatCompactNumber(currentFdv)}</strong>
          </div>
          <div class="metric-row">
            <span class="metric-label">基准估值区间</span>
            <strong>${baseScenario ? formatUsdRange(baseScenario.targetFdvRange) : "暂无"}</strong>
          </div>
          <div class="metric-row">
            <span class="metric-label">当前所处区间</span>
            <strong>${zoneLabel(valuationZone)}</strong>
          </div>
          <div class="metric-row">
            <span class="metric-label">现价 / 成本</span>
            <strong>${currentPrice ?? "暂无"} / ${averageCost ?? "暂无"}</strong>
          </div>
        </div>
        <div class="muted" style="margin-top:6px;">
          来源数：${sources.length} · 最近事件：${recentEvent?.title || "暂无"}
        </div>
        <div style="margin-top:8px;"><code>${normalizePlanText(plan?.sellZone || "等待生成计划")}</code></div>
      </div>
    `;
  });

  root.innerHTML = items.length ? items.join("") : `<div class="muted">还没有资产被纳入管理。</div>`;
}

function renderEvents(events) {
  const root = document.getElementById("events");
  root.innerHTML = events.length
    ? events
        .slice()
        .reverse()
        .map(
          (event) => `
            <div class="card">
              <strong>${event.title}</strong>
              <div class="muted" style="margin-top:6px;">${event.summary || event.type}</div>
              <div class="muted" style="margin-top:6px;">${event.createdAt || event.date || ""}</div>
            </div>
          `
        )
        .join("")
    : `<div class="muted">还没有事件记录。</div>`;
}

function renderTraces(traces) {
  const root = document.getElementById("traces");
  root.innerHTML = traces.length
    ? traces
        .slice()
        .reverse()
        .map(
          (trace) => `
            <div class="card">
              <div style="display:flex;justify-content:space-between;gap:12px;">
                <strong>${trace.userIntent}</strong>
                <span class="muted">${trace.createdAt || ""}</span>
              </div>
              <div style="margin-top:6px;">${trace.finalRecommendation}</div>
              <div class="muted" style="margin-top:6px;">${(trace.reasons || []).join("；")}</div>
            </div>
          `
        )
        .join("")
    : `<div class="muted">还没有决策记录。</div>`;
}

async function boot() {
  const response = await fetch("/api/state");
  const state = await response.json();
  renderStats(state.counts);
  renderAssets(state);
  renderEvents(state.recentEvents);
  renderTraces(state.recentTraces);
}

boot();
