import { mkdir, readFile, rename, stat, writeFile } from "node:fs/promises";
import { dirname } from "node:path";

import { DEFAULT_SETTINGS } from "./config.mjs";
import { resolveStateFilePath } from "./paths.mjs";

function baseState() {
  return {
    version: 1,
    settings: DEFAULT_SETTINGS,
    assets: {},
    positions: {},
    sources: {},
    researchReports: {},
    valuationModels: {},
    plans: {},
    events: {},
    traces: {},
    monitorState: {}
  };
}

function normalizeState(state) {
  const empty = baseState();
  return {
    ...empty,
    ...state,
    settings: {
      ...empty.settings,
      ...(state.settings || {}),
      monitorIntervals: {
        ...empty.settings.monitorIntervals,
        ...(state.settings?.monitorIntervals || {})
      },
      maxAllocationByRiskClass: {
        ...empty.settings.maxAllocationByRiskClass,
        ...(state.settings?.maxAllocationByRiskClass || {})
      }
    },
    assets: state.assets || {},
    positions: state.positions || {},
    sources: state.sources || {},
    researchReports: state.researchReports || {},
    valuationModels: state.valuationModels || {},
    plans: state.plans || {},
    events: state.events || {},
    traces: state.traces || {},
    monitorState: state.monitorState || {}
  };
}

async function ensureDataDir(dataFile) {
  await mkdir(dirname(dataFile), { recursive: true });
}

export class DataStore {
  constructor() {
    this.state = null;
    this.loadedFromPath = null;
    this.lastKnownMtimeMs = null;
  }

  dataFile() {
    return resolveStateFilePath();
  }

  async load() {
    const dataFile = this.dataFile();
    if (this.loadedFromPath && this.loadedFromPath !== dataFile) {
      this.state = null;
      this.loadedFromPath = null;
      this.lastKnownMtimeMs = null;
    }

    if (this.state) {
      try {
        const fileStat = await stat(dataFile);
        if (this.lastKnownMtimeMs !== null && fileStat.mtimeMs !== this.lastKnownMtimeMs) {
          this.state = null;
          this.loadedFromPath = null;
          this.lastKnownMtimeMs = null;
        }
      } catch {
        this.state = null;
        this.loadedFromPath = null;
        this.lastKnownMtimeMs = null;
      }
    }

    if (this.state) {
      return this.state;
    }
    await ensureDataDir(dataFile);
    try {
      const raw = await readFile(dataFile, "utf8");
      this.state = normalizeState(JSON.parse(raw));
      this.loadedFromPath = dataFile;
      this.lastKnownMtimeMs = (await stat(dataFile)).mtimeMs;
    } catch {
      this.state = baseState();
      this.loadedFromPath = dataFile;
      await this.save();
    }
    return this.state;
  }

  async save() {
    const dataFile = this.dataFile();
    await ensureDataDir(dataFile);
    const tempFile = `${dataFile}.tmp`;
    await writeFile(tempFile, JSON.stringify(this.state, null, 2));
    await rename(tempFile, dataFile);
    this.loadedFromPath = dataFile;
    this.lastKnownMtimeMs = (await stat(dataFile)).mtimeMs;
  }

  async update(mutator) {
    const state = await this.load();
    const result = await mutator(state);
    await this.save();
    return result;
  }

  resetCache() {
    this.state = null;
    this.loadedFromPath = null;
    this.lastKnownMtimeMs = null;
  }

  async clear() {
    this.state = baseState();
    this.loadedFromPath = this.dataFile();
    this.lastKnownMtimeMs = null;
    await this.save();
    return this.state;
  }
}

export const store = new DataStore();
